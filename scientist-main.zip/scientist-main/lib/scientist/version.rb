module Scientist
  VERSION = '1.6.4'
end
