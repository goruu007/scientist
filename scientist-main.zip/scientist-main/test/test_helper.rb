require "minitest/autorun"

$LOAD_PATH.unshift(File.expand_path(File.join(__dir__, "../lib")))
require "scientist"
